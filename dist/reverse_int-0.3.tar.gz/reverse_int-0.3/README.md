
Python lib to reverse an integer.

# Example
```sh
import reverse_int
print(reverse_int.reverse(1234))
4321
```


