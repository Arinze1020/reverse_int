# Project description
[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)
Python lib to reverse an integer.

### Installation
```sh
$ pip install reverse_int
```
# Example
```sh
import reverse_int
print(reverse_int.reverse(1234))
4321
```


